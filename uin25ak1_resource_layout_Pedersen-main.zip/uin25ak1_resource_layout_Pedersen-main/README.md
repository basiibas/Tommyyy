# uin25ak1_resource_layout_Pedersen
 
